
;(function($) {
	var pluginName = 'scheck';

	function Plugin(element, options) {
		var el = element;
		var $el = $(element);

		options = $.extend({}, $.fn[pluginName].defaults, options);
		var wrong = false;
		var checked = false;
		var image;
		var imageUnchecked = "";
		var imageChecked = "";
		
		function init() {
			
			imageUnchecked = (options.type=="check") ? 	"images/22-unchecked.gif" : "images/22-unchecked-radio.gif";
			imageChecked = (options.type=="check") ? 	"images/22-checked.gif" : "images/22-checked-radio.gif";
			image = $("<img src='" + imageUnchecked + "' />").appendTo(element); 
			image.css({
				cursor:'pointer',
				position:'absolute',
				verticalAlign:'middle',
				width: 22,
				height: 22,
				top: ($(element).height()- image.height()) /2
			}).click(clickMe); 
			
			if(options.mode == "review" && wrong == true) {
				image.src = "images/22-cross.gif";
			} else if (options.mode == "review" && wrong == false) {
				image.src = "images/22-check.gif";
			}
			
			$("<label>", {css:{width:'auto', paddingRight:10, cursor:'pointer'}}).appendTo(element).text(options.label).click(clickMe); 
			hook('onInit');
		}

		
		function clickMe() {
			if(options.mode == "quiz") {
				checked = !checked;
				toggleImage();
			}
			hook('onValueChanged');
		}
		
		function toggleImage() {
			if(checked) {
                image.attr("src", imageChecked);
            } else {
                image.attr("src", imageUnchecked);
            }
		};
		
		
		//  ==============  public accessivle functions  ===================
		/**
		 * @param value Boolean
		 * @param trigger Boolean
		 */
		function setValue(value,trigger) {
			checked = value;
			//if(trigger) hook('onValueChanged');
			toggleImage();
		};
		
		/**
		 * @returns String checked | ""
		 */
		function getValue() {
			if (checked){
				return 'checked';
			} else {
				return "";
			}
		};
		
		function option (key, val) {
			if (val) {
				options[key] = val;
			} else {
				return options[key];
			}
		};

		function destroy() {
			$el.each(function() {
				var el = this;
				var $el = $(this);

				// Add code to restore the element to its original state...

				hook('onDestroy');
				$el.removeData('plugin_' + pluginName);
			});
		};

		function hook(hookName) {
			if (options[hookName] !== undefined) {
				options[hookName].call(el);
			}
		};

		init();

		return {
			option: option,
			destroy: destroy,
			getValue: getValue,
			setValue: setValue
		};
	}

	$.fn[pluginName] = function(options) {
		if (typeof arguments[0] === 'string') {
			var methodName = arguments[0];
			var args = Array.prototype.slice.call(arguments, 1);
			var returnVal;
			this.each(function() {
				if ($.data(this, 'plugin_' + pluginName) && typeof $.data(this, 'plugin_' + pluginName)[methodName] === 'function') {
					returnVal = $.data(this, 'plugin_' + pluginName)[methodName].apply(this, args);
				} else {
					throw new Error('Method ' +  methodName + ' does not exist on jQuery.' + pluginName);
				}
			});
			if (returnVal !== undefined){
				return returnVal;
			} else {
				return this;
			}
		} else if (typeof options === "object" || !options) {
			return this.each(function() {
				if (!$.data(this, 'plugin_' + pluginName)) {
					$.data(this, 'plugin_' + pluginName, new Plugin(this, options));
				}
			});
		}
	};

	$.fn[pluginName].defaults = {
			onInit: function() {},
			onDestroy: function() {},
			onValueChanged: function () {},
			type: "check",
			mode: "quiz",
			label: "Label"
	};

})(jQuery);