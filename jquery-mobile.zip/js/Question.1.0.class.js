/**
 * Question Class
 * For every question a question object is build which is hold in an array
 * in the Quiz engine.
 * 
 * Every question contains an Answer object which holds all the answers
 * as scheck or squiz button. 
 * Answer object fires 'ready' event if answer count is correct
 * Answer object fires 'answerCountError' event if to much answers are checked
 * Answer object can return the type (radio or check) and the number of correct answers
 * 
 * 
 */

var Question = function (options) {
	
	var mode = (options.mode == undefined) ? "quiz" : "review";
	var question = options.question;
	var prefix = options.prefix;
	var answers = "";									// holds the Answer object with all answers
	//var result = new Array();							// holds question number
	var qListener = options.questionListener;			// function that act as listener in SQuiz for zthis question
	var correctWrapperHeightListener = options.fixHeightListener;
	var singlechoicehint = options.singlechoicehint;
	var multiplechoicehint = options.multiplechoicehint;
	var number = options.number;
	
	this.createAnswers = function (xml) {
		answers = new Answers(xml, prefix, listener);
	};
	
	/**
	 * @private
	 * Listens to the answers events ready, answerCountError to switch the navigation buttons and
	 * save the answer status in the result array.
	 * @param event : String event type
	 * @param obj : the Answer Class instance reference
	 */
	function listener(event, obj) {
		if(event == "ready") {
			qListener(event,obj );
		} else if (event == "answerCountError") {
			qListener(event,obj);
		}
	};
	
	/**
	 * @public
	 * Show the question and answers
	 */
	this.showQuestion = function ( ) {
		$("#" + prefix + "_quiz_question").html("<p>" + number + ". " + question + "</p>");
		var correct = answers.getCountCorrect();
		var multihint = multiplechoicehint.replace("[$]", " " + correct + " ");
		var hint = (answers.getType() == "radio") ? "<p>" + singlechoicehint + "</p>" : "<p>" + multihint + "</p>";
		$("#" + prefix + "_quiz_hint").html(hint);
		
		/** show answer and call fixing the height of the wrapper **/
		answers.showAnswers(correctWrapperHeightListener);
	};
	
	// ==============  getter  // setter  =========================
	
	this.getQuestion = function () { return question;};
	this.getAnswers = function() { return answers.getAnswers(); };
	
	
};