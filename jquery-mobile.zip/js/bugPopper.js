// JavaScript Document

window.addEventListener('load',init,false);
var canvas;
var ctx;
var canvasX=[];
var canvasY=[];
var mosquito=[];
var numberOfMosquitosSmooshed=0;
var mouseIsDown = 0;
var soundEfxBuzz = new Audio("audio/Mosquito-Buzzing.wav");
var soundEfxSplat = new Audio("audio/splat.wav");
var health = 10;
var gameOverEfx = new Audio("audio/gameOver.wav");

var linkText="http://www.ChildFund.org";
var linkX=90;
var linkY=340;
var linkHeight=10;
var linkWidth;
var inLink = true;


CanvasRenderingContext2D.prototype.wrapText = function (text, x, y, maxWidth, lineHeight) {

    var lines = text.split("\n");

    for (var i = 0; i < lines.length; i++) {

        var words = lines[i].split(' ');
        var line = '';

        for (var n = 0; n < words.length; n++) {
            var testLine = line + words[n] + ' ';
            var metrics = this.measureText(testLine);
            var testWidth = metrics.width;
            if (testWidth > maxWidth && n > 0) {
                this.fillText(line, x, y);
                line = words[n] + ' ';
                y += lineHeight;
            } else {
                line = testLine;
            }
        }

        this.fillText(line, x, y);
        y += lineHeight;
    }
};


function init(){
	canvas= document.getElementById("canvas");
    	ctx=canvas.getContext("2d");
        //Create Event Listener for mouse movements
        //format should be: addEventListener("nameOfEvent",referenceToFunction,phase)
        
        canvas.addEventListener("mouseup",mouseUp,false);
		
		canvas.addEventListener("mousedown",mouseDown, false);
		
		canvas.addEventListener("mousemove",mouseMove, false);
		
		//create initial 6 y locations/paths for mosquitos
		
		for (i=0;i<6;i++){
				mosquito[i]=400+70*i;
			}
			
			runGame();
}

function mouseUp(){
	mouseIsDown = 0;
	mouseMove();
	}
function mouseDown(){
	mouseIsDown = 1;
	mouseMove();
	}

function mouseMove(e){
	e.preventDefault();
    canvasX[0]=e.pageX - canvas.offsetLeft;//current x position of mouse cursor
	canvasY[0]=e.pageY - canvas.offsetTop;//current y position of mouse cursor
	
}

//smooshing of Mosquitos scoreboard
function numberOfMosquitosSmooshedDisplay(){
		ctx.font = "bold 12px Arial";
		ctx.fillText("Score:"+numberOfMosquitosSmooshed, 229,20);
	}

function healthDisplay(){
		ctx.font="bold 12px Arial";
		ctx.fillText("Life Remaining:"+health, 24,20);//display health/lives left
	}
	
function gameOver(){
		ctx.fillStyle="rgba(10,10,0,1)";
		ctx.font="bold 24px Arial";
		ctx.fillText("Game Over",100,55);
		ctx.fillText("You have Malaria",50,90);
		ctxfillStyle="rgba(10,10,0,1)";
		ctx.font="bold 22px Arial";
		ctx.fillText("Score:"+numberOfMosquitosSmooshed, 100,130);
		ctx.fillStyle="rgba(10,10,0,1)";
		ctx.font="bold 16px Arial";
		ctx.wrapText("Thank you for playing.\n\nNearly half the world’s population is at risk for malaria. In Africa, a child dies every minute from the disease. \n\nSomething as simple as a treated mosquito net can save a child’s life. You can help end this preventable but deadly disease by donating to ChildFund’s fight against malaria today. Click “Give” now to donate. \n\nSources: Centers for Disease Control, World Health Organization.",30,170,280,17);
		//draw the link
   		
 
    //add mouse listeners
    	canvas.addEventListener("mousemove", on_mousemove, false);
    	canvas.addEventListener("click", on_click, false);
		//this is where to add the Social Share Feature
		gameOverEfx.play();
	}	
	
	//check if the mouse is over the link and change cursor style
function on_mousemove (ev) {
  var x, y;
 
  	// Get the mouse position relative to the canvas element.
  if (ev.layerX || ev.layerX) { //for firefox
    x = ev.layerX;
    y = ev.layerY;
  }
  x-=canvas.offsetLeft;
  y-=canvas.offsetTop;
 
  	//is the mouse over the link?
  if(x>=linkX && x <= (linkX + linkWidth) &&
     y<=linkY && y>= (linkY-linkHeight)){
      document.body.style.cursor = "pointer";
      inLink=true;
  }
  else{
      document.body.style.cursor = "";
      inLink=false;
  }
}
 
	//if the link has been clicked, go to link
function on_click(e) {
  if (inLink)  {
    window.location = linkText;
  }
}
 	
	
	
function showMousePosition(){
	ctx.font="12px Arial";
    ctx.textAlign="center";
    ctx.textBaseline="middle";
    	ctx.fillStyle="rgb(255,255,255)";
    
    var str = "x = " + canvasX + "," + " y = " + canvasY;
    
    //Clear canvas b4 dsiplaying new coords
    
   	ctx.clearRect(0,0,canvas.width,canvas.height);
    	ctx.fillText(str, canvas.width / 2, canvas.height / 2, canvas.width - 10 );
}

function runGame(){
 var img = new Image();
 img.src=('images/Mosquito.png');
//ctx.fillStyle="rgba(25,5,255,0.3)";
	ctx.fillStyle=img;
	ctx.fill();
	ctx.clearRect(0,0, canvas.width, canvas.height);
				
		if (health<=0){
			gameOver();
		}
		else{
		//draw 6 bubbles/mosquitos	
		for(i=0;i<8;i++){
		mosquito[i]--;//Mosquito 'i' moves upward, 1 unit, pixels in this case and it's y coord is decreased by 1.  if it happens to move off the canvas, return it to the original y location/path.
		if (mosquito[i]<= canvas.height - 480){
				mosquito[i]=400+70*i;
				health--;//lose 1 health for each bug that crosses off screen
			}
			healthDisplay();//display current health
		var y = mosquito[i];
		var x = (i+1)*43;
		
		var radius = 20
		ctx.beginPath();
		ctx.arc(x,y, radius, 0,2*Math.PI);
		
		ctx.closePath();
		soundEfxBuzz.play();
		
		if (ctx.isPointInPath(canvasX[0], canvasY[0])&& mouseIsDown){
				mosquito[i]=400 +70*i;
					numberOfMosquitosSmooshed++;
					soundEfxSplat.play();
			}
		numberOfMosquitosSmooshedDisplay();//displays score
		ctx.fill();
		}
		setTimeout("runGame()",13);
	}
}
