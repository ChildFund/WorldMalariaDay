/**
 * Answer Class
 * 
 * Events:
 * ready: all possible answers are checked
 * answerCoountError: to much answers are checked
 * 
 */

var Answers = function (xml, classPrefix, eventListener) {
	var me = this;
	var type;					// multiple choice (check) or single choice (radio)
	var countCorrect = 0;		// how much answers are correct
	var content = xml;			// all answers as xml
	var parent = $("#" + classPrefix + "_quiz_answers");
	var answerObjects = new Array();		// holds all answer DOM objects
	var userSelection = new Array(); 		// holds all user selected answers
	var eventListener;

	// determine if it is a single or multiple choice question
	// and what type the question is of
	xml.each(function() {
		var a = $(this);
		if(a.attr("correct") == "true") countCorrect++;
	});
	if(countCorrect == 1) {
		type = "radio";
	} else if(countCorrect > 1) {
		type = "check";
	} else {
		alert("Error in question: " + "\n" + content.parent().first().text() + "\n: no correct choice marked");
	}
		
	/**
	 * Is called by Question class with the answer xml data
	 * Removes the old answers if present and calls after that
	 * displayNewAnswers to show the brand new answers
	 * @public
	 * 
	 */
	this.showAnswers = function (correctWrapperHeightListener) {
		// clear the answer section
		var count = $("#" + classPrefix + "_quiz_answers > div").size();
		
		if(count == 0) {
			displayNewAnswers(correctWrapperHeightListener);	
		} else {
		
			$("#" + classPrefix + "_quiz_answers").children().each(function(){
				$(this).fadeOut(function() {
					count--;
					$("#" + classPrefix + "_quiz_answers").empty();
					if(count == 0) {
						displayNewAnswers(correctWrapperHeightListener);	
					}
				});
			});
		}
	};
	
	function displayNewAnswers  (correctWrapperHeightListener) {
		// initialize answerArray
		answerObjects = new Array();
		var answerId = 0;
		content.each(function() {
			var a = $(this);
			var id = Math.floor(Math.random() * 1000000);
			var aDiv = $("<div>").appendTo(parent).addClass(classPrefix + "_quiz_awrapper").hide();
			// add the answer (as formtype or quiztype)
			var answerObject = $("<div>",{id:id}).addClass(classPrefix + "_quiz_answer").appendTo(aDiv).scheck({
				type: type,
				label: a.text(),
				onValueChanged: answerChanged
			});
			// save the position of this answer and the correct value in the object
			answerObject.id = answerId;
			//answerObject.divId = id;
			answerObject.correctAnswer = a.attr("correct");
			answerObject.answer = a.text();
			answerObjects.push(answerObject);
			answerId++;
			aDiv.show("slow", function() {
				/** call the height correction of the wrapper **/
				correctWrapperHeightListener();
			});
		});
	};
	
	/**
	 * @public
	 * @param answerId: Number 	the answer id to be marked
	 * @param markType : String	checked, wrong, right
	 */
	this.markAnswer = function(answerId, markType) {
		switch(markType) {
		case "checked":	// if question is already answered and this answer is checked in quizmode
			$(answerObjects[answerId]).scheck("setValue", true, true);
			break;		
		}
		
	};
	
	/**
	 * The listener function for the answer buttons change event
	 * @param event
	 * @param param
	 */
	function answerChanged(eventObj) {
		userSelection = new Array();
		// change all other radio buttons to unchecked
		if(type == "radio") {
			for( i in answerObjects) {
				if(answerObjects[i].attr("id") != $(this).attr("id")) {
					$(answerObjects[i]).scheck('setValue', false)
				} else if(answerObjects[i].attr("id") == $(this).attr("id")) {
					userSelection.push(answerObjects[i]);
				}
			}
			// fire the ready event to notify the question class that the question is completly answered
			eventListener('ready', me);
		} else {
			var count = 0;
			for( i in answerObjects) {
				if($(answerObjects[i]).scheck('getValue') == "checked") {
					userSelection.push(answerObjects[i]);
					count++;
				}
			}
			if(count == countCorrect) {
				eventListener('ready', me);
			} else if(count != countCorrect) {
				eventListener('answerCountError', me);
			}
		}
	}
	
	//  =============  getter  //  setter  ======================
	this.getType = function() {return type; };
	this.getCountCorrect = function () { return countCorrect; };
	this.getUserSelection = function () { return userSelection; };	// the answerObjects the user selected
	this.getAnswers = function () { return answerObjects; };		// all answerObjects
	/**
	 * @public
	 * Returns the number of points earned by the candidate with this question
	 */
	this.getPoints = function () {
		
	};
	this.toString = function () {
		this.getType() + "*";
	};
	
};