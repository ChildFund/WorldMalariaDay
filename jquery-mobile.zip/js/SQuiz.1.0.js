var SQuiz = function () {
	// general settings
	var prefix = "";   	// the style class prefix
	var questions = new Array();
	// quiz settings
	var timeLimit = 0;	// 0 = no limit, no timer visible, else limit in seconds
	var questionId = 0;
	// quiz text elements
	var nextbutton = "";
	var prevbutton ="";
	var finishbutton = "";
	var startbutton = "";
	var reviewbutton = "";
	var resultscreentitle = "";
	var resultscreenresultline = "";
	var welcometext = "";
	var singlechoicehint = "";
	var multiplechoicehint = "";
	var startTime = "";				// time quiz starts
	var timeCounter = 0;			// aux variable
	var elapsed = "";				// time elapsed since quiz starts
	var timerInstance = "";			// the interval instance
	
	userAnswers = new Array();
	
	
	this.init = function (options) {
		
		prefix = options.prefix;
		filename = options.quiz;
		$("#" + prefix + "_prev").hide();
		$("#" + prefix + "_next").hide();
		
		loadData();
		
		$("#" + prefix + "_start").click(function () {
			userAnswers = new Array();
			$(this).hide("slow", function() {
				 questionId = 0;
				 go();
			});	
			$("#" + prefix + "_next").show();
			//$("#" + prefix + "_next").val( nextbutton);
			$("#" + prefix + "_prev").show();
			nextButtonDefault();
			$("#" + prefix + "_prev").unbind('click');
			$("#" + prefix + "_prev").click(function () {
				// everytime:
				nextButtonDefault();
				questionId--;
				go();
			});
			if(!$.support.opacity)  ieFix();
			// start the timer
			elapsed = 0;
			timeCounter = 0;
			startTime = new Date().getTime();
			timerInstance = setTimeout(timerCallback, 1000);
		});
		
	};
	
	// =============  service functions =================
	// load a specified quiz file
	function loadData(){
		$.ajax({
	        type: 'POST',
	        url: "repository/" + filename,
	        dataType: 'xml',
	        success: function(xml) {
	        	var xml = $(xml).find("quiz");
	        	$("#" + prefix + "_quiz_title").text($(xml).find("title").text());
	        	nextbutton = $(xml).find("nextbutton").text();
	        	$("#" + prefix + "_next").val( nextbutton);
	        	$("#" + prefix + "_prev").val($(xml).find("prevbutton").text());
	        	singlechoicehint = $(xml).find("singlechoice").text();
	        	multiplechoicehint = $(xml).find("multiplechoice").text();
	        	finishbutton = $(xml).find("finishbutton").text();
	        	resultscreentitle = $(xml).find("resultscreentitle").text();
	        	resultscreenresultline = $(xml).find("resultscreenresultline").text();
	        	startbutton = $(xml).find("startbutton").text();
	        	reviewbutton = $(xml).find("reviewbutton").text();
	        	welcometext = $(xml).find("welcometext").text();
	        	$("#" + prefix + "_quiz_hint").html( welcometext);
	        	$("#" + prefix + "_start").val( startbutton);
	        	timeLimit = $(xml).find("time").text();
	        	var number = 0;
	        	xml.find("question").each(function(){
	        		var q = $(this);
	        		number++;
	        		//console.log(q.contents().first().text());
	        		var question = new Question({
	        			question:q.contents().first().text(),
	        			prefix: prefix,
	        			number: number,
	        			fixHeightListener: fixWrapperHeight,
	        			questionListener: questionListener,
	        			singlechoicehint: singlechoicehint,
	        			multiplechoicehint: multiplechoicehint	        			
	        		});
	        		question.createAnswers(q.children("answer"));
	        		questions.push(question);

	        	});
	        	//console.log("loaded");
	        	// go( questionId);
	        } // end success ajax
	    }); // end ajax
		
		
		
	};  // end loadData
	
	/**
	 * Everytime a next or previouus button is clicked, this function is called.
	 * 1. case: User has not answered the question.
	 * 		Show the question and answers
	 */
	function go() {
		//console.log("QuestionId " + questionId);
		// clear the answer section
		$("#" + prefix + "_quiz_answers").empty();
		// show the new question and fix wrapper height
		questions[questionId].showQuestion();
		showMarkedAnswers ();
		// all questions answered, last question is reached if 
		if( userAnswers.length == questions.length && questionId == questions.length - 1) { 
			
			nextButtonToFinishButton();
		} else {
			// disable next button if next question is NOT answered
			if(userAnswers.length < questionId + 1) {
				$("#" + prefix + "_next").attr("disabled", "disabled");
			} else {
				$("#" + prefix + "_next").removeAttr("disabled");
			}
			// We are not at the end of the quiz, show the 'prev' button
			
			// We are at the beginning of the quiz, disable the prev button
			if( questionId == 0) $("#" + prefix + "_prev").attr("disabled", "disabled");
			if(!$.support.opacity)  ieFix();
		}
	};
	
	/**
	 * If a question is already answered mark the user answers
	 */
	function showMarkedAnswers () {
		// there is already an answer object for the specified question ID
		if( userAnswers[questionId] != undefined ) {
			var answersArray =  userAnswers[ questionId].getUserSelection();
			for(var i = 0; i < answersArray.length; i++){
				// mark all answers 
				 userAnswers[ questionId].markAnswer(answersArray[i].id, "checked");
			}
		}
		if( questionId <= questions.length - 1) $("#" + prefix + "_prev").removeAttr("disabled");
	};
	
	function evaluation() {
		//console.log("evaluation");
		// clear question, answer and hint
		$("#" + prefix + "_quiz_question").html("");
		$("#" + prefix + "_quiz_hint").html("");
		$("#" + prefix + "_quiz_answers").html("");
		// stop timer
		clearTimeout(timerInstance);
		var html = "<p>" +  resultscreentitle + " <br>";
		var correctAnswers = 0;

		for(var i in userAnswers) {
			var answers = userAnswers[i].getUserSelection();
			var correct = true;
			for( var a in answers) {
				// if one of the possible answers is wrong, mark question complete as wrong
				if(answers[a].correctAnswer == "false") correct = false;
			}
			if(correct == true) correctAnswers++;
		}
		var percent = (Math.floor(correctAnswers /  questions.length * 1000)) / 10;
		html += percent + " % " +  resultscreenresultline + " ( " + fmtTime(elapsed) + " )</p>";
		$("#" + prefix + "_quiz_question").html(html);
		review();
	};
	
	/**
	 * Show all answers in the _quiz_answers div with the result
	 */
	function review () {
		var i = 0;
		$("#" + prefix + "_quiz_answers").hide();
		for(i in questions) {
			if(userAnswers[i] !== undefined) {
				var answers = userAnswers[i].getUserSelection();
				var correct = true;
				for( var a in answers) {
					// if one of the possible answers is wrong, mark question complete as wrong
					if(answers[a].correctAnswer == "false") correct = false;
				}
			} else {
				var correct = false;
			}
			var qNumber = i;
			var bgImageClass = (correct == false) ? "wrong" : "correct";
			$("<div>").text(++qNumber).addClass(bgImageClass).addClass(prefix + "_quiz_reviewdiv").appendTo($("#" + prefix + "_quiz_answers"));
		};
		// real height is only in hide mode available. So fix the wrapper height and after that
		// show the reviews
		fixWrapperHeight();
		$("#" + prefix + "_quiz_answers").show("slow");
		
	};	
	
	function timerCallback () {
		var exit = false;
		timeCounter += 1000;  
		elapsed = Math.floor(timeCounter / 100) / 10;  
		var currQuestion = questionId + 1;
		if(timeLimit > 0) { // we use the time limit
			$("#" + prefix + "_quiz_timer").text(currQuestion + "/" + questions.length + " - " + fmtTime(timeLimit - elapsed));
			// make the clock red if last 10 seconds begin
			if(timeLimit - elapsed < 11) {
				$("#" + prefix + "_quiz_timer").css("color", "#F00");
			}
			if(timeLimit - elapsed <= 0) { // this is the end
				exit = true;
				// the previous button must be hidden here because quiz is at the end
				$("#" + prefix + "_prev").hide("slow");
				endQuiz();
			}
		} else {  // show only the elapsed time
			$("#" + prefix + "_quiz_timer").text(currQuestion + "/" + questions.length + " - " + fmtTime(elapsed));
		}
		// calculate the difference between the interval and the real elapsed interval
		var diff = (new Date().getTime() - startTime) - timeCounter;  
		if(exit == false) timerInstance = setTimeout(timerCallback, (1000 - diff));  
	};
	
	function fmtTime (value) {
		var hours = Math.floor(value / 3600);
		var minutes = Math.floor((value - (hours * 3600)) / 60);
		if(minutes < 10) minutes = "0" + minutes;
		var seconds = value % 60;
		if(seconds < 10) seconds = "0" + seconds;
		return hours + ":" + minutes +":"+ seconds;
	};
	
	//  ============  gui manipulation  ======================================

	function nextButtonDefault () {
		//console.log("nextButtonDefault");
		$("#" + prefix + "_next").unbind('click');
		$("#" + prefix + "_next").val( nextbutton);
		$("#" + prefix + "_next").click(function () {
			 questionId++;
			 go();
		});
	};	
	
	function nextButtonToFinishButton () {
		//console.log("nextButtonToFinishButton");
		$("#" + prefix + "_next").unbind('click');
		$("#" + prefix + "_next").val(finishbutton).click(function() {
			// remove previous button
			$("#" + prefix + "_prev").hide("slow");
			$(this).hide("slow");
			//$("#" + prefix + "_quiz_hint").html( welcometext);
			$("#" + prefix + "_start").val( startbutton).show("slow");
			evaluation();
		});
	};	
	
	function ieFix() {
		if($("#" + prefix + "_next").attr("disabled") == "disabled") {
			$("#" + prefix + "_next").addClass("iefix");
		} else {
			$("#" + prefix + "_next").removeClass("iefix");
		}
		if($("#" + prefix + "_prev").attr("disabled") == "disabled") {
			$("#" + prefix + "_prev").addClass("iefix");
		} else {
			$("#" + prefix + "_prev").removeClass("iefix");
		}
	};
	
	function fixWrapperHeight() {
		// a this point the answers are rendered so far
		var targetHeight = 0;
		$("#" + prefix + "_quiz_wrapper").children().each(function () {
			targetHeight += $(this).height();
		});
		targetHeight += $("#" + prefix + "_quiz_navigation").height();
		$("#" + prefix + "_quiz_wrapper").stop().animate({
			height:targetHeight
		});
	};
	//  =============  listener  and service  ================================
	function questionListener(event, ans) {
		//console.log("questionListener");
		if(event == "ready") {
			$("#" + prefix + "_next").removeAttr("disabled");
			 userAnswers[ questionId] = ans;
			 debug();
			// if he answered the last question change next button label and the callback
			if( questionId == questions.length - 1) {
				/*
				$("#" + prefix + "_next").val(finishbutton).click(function() {
					// remove previous button
					$("#" + prefix + "_prev").hide("slow");
					$(this).hide("slow");
					//$("#" + prefix + "_quiz_hint").html( welcometext);
					$("#" + prefix + "_start").val( startbutton).show("slow");
					 evaluation();
				});*/
				nextButtonToFinishButton();
			}
		} else {
			$("#" + prefix + "_next").attr("disabled", "disabled");
		}
		if(!$.support.opacity)  ieFix();
	};
	
	function endQuiz () {
		// clear question, answer and hint
		$("#" + prefix + "_quiz_question").html("");
		$("#" + prefix + "_quiz_hint").html("");
		$("#" + prefix + "_quiz_answers").html("");
		// change the button state
		$("#" + prefix + "_next").removeAttr("disabled");
		$("#" + prefix + "_next").unbind('click');
		if(!$.support.opacity)  ieFix();
		// change NEXT button to FINISH button
		$("#" + prefix + "_next").val( finishbutton).click(function() {
			// remove previous button
			$("#" + prefix + "_prev").hide("slow");
			$(this).hide("slow");
			//$("#" + prefix + "_quiz_hint").html( welcometext);
			$("#" + prefix + "_start").val( startbutton).show("slow");
			 evaluation();
		});
	};
	
	function debug() {
		/*
		var answerNumber = questionId;
		var html = "<p>Useranswers: " +  userAnswers.length + "<br>";
		for(var i in  userAnswers) {
			html += "Question id: " + i + "<br>";
			html += "User selected:<br>";
			// userAnswers holds the complete uanswer obj
			// obj.getUserSelection() holds user selected answers
			//console.log( userAnswers[i].getUserSelection().length);
			for( var a in  userAnswers[i].getUserSelection()) {
				html += "a: " +  userAnswers[i].getUserSelection()[a].id + "<br>";
			}
		}
		html +="</p>";
		html += "<p>count: " +  questions.length + "<br>";
		html += "answered: " + (answerNumber + 1) + "</p>";
		$("#debug").html(html);
		*/
	};
};

